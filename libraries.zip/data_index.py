from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3


host = 'vpc-photos-7qa33hpnrbg2mkgppan2tweyie.us-east-1.es.amazonaws.com' # For example, my-test-domain.us-east-1.es.amazonaws.com
region = 'us-east-1' # e.g. us-west-1
ACCESS_KEY = 'AKIAJQ2GNHDJWSZAEX5A'
SECRET_KEY = 'TYX1jiJaAEA5ZOutqLoZCLHynNw35rTeuS1/if8P'

def authenticate_user(service):
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(ACCESS_KEY, SECRET_KEY, region, service)
    return awsauth

def connect_to_elastic_search():
    service = 'es'
    awsauth = authenticate_user(service)
    es = Elasticsearch(
            hosts = [{'host': host, 'port': 443}],
            http_auth = awsauth,
            use_ssl = True,
            verify_certs = True,
            connection_class = RequestsHttpConnection
        )
    
    return es